<?php
session_start();

include_once 'db.php';

if (isset($_GET['id'])) {
    $id=$_GET['id'];

    $query_delete = "DELETE FROM command WHERE id = '$id'";
    $result_delete = $connection->query($query_delete);

    header('Location: ' . $_SERVER['HTTP_REFERER']);
}

else {
    header('Location: sign');
}
?>
